
import './App.css';
import {useReducer,useState} from 'react';

function App() {

  const initialState={
    count:0
  }
  const reducerFun=(state,action)=>{
    switch(action.type){
      case "INCREMENT":
        return{
          ...state,
          count:state.count + 1
        }
        case "DECREMENT":
          return{
            ...state,
            count:state.count - 1
          }
        default:
          return state
    }
    
  }

    const [state,dispatch]= useReducer(reducerFun,initialState);
    const onDecClick=()=>{
      dispatch({type: "DECREMENT"})
    }

  return (
    <div>
    <>
      <h1>{state.count}</h1>
      <button onClick={()=>dispatch({type: 'INCREMENT' , payload:'1234'})}>INC</button>
      <button onClick={onDecClick}>DEC</button>
    </>
    </div>
  );
}

export default App;
